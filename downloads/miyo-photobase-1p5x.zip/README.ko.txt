미요 · 포토베이스
101×54 px, 14프레임, GIF 40ms/프레임, 스프라이트 시트.
RunCat Neo용: frames-runcat-neo 폴더의 76×36 PNG를 가져오세요. 실루엣 높이 약 1.13배입니다. 101×54 1.5배 원본은 앱 가져오기용이 아닙니다.
RunCat Neo 표준 프레임 묶음: miyo-photobase-neo-frames.zip (0번부터 13번까지 PNG만 포함). 앱이 ZIP 대신 프레임 폴더를 요구하면 압축을 풀어 사용하세요.
