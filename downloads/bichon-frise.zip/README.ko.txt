비숑 프리제 · RunCat 도트 러너
투명 PNG 67 × 36px · 8프레임 · 한 바퀴 560ms
ZIP에는 이미지 파일만 포함되어 있습니다. RunCat 앱은 포함되지 않습니다.
원본: https://github.com/limdoglim/runcat_more_runner/tree/main/concepts/bichon-frise/pixel-runner
