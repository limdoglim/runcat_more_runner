미요 · 포토베이스
67×36 px, 14프레임, GIF 40ms/프레임, 스프라이트 시트.
RunCat Neo 표준 프레임 묶음: miyo-photobase-frames.zip (0번부터 13번까지 PNG만 포함). 앱이 ZIP 대신 프레임 폴더를 요구하면 압축을 풀어 사용하세요.
